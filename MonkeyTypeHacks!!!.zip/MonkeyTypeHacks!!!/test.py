file = open("Debug.txt", "a+")
print(file.read())