import pytesseract
from PIL import Image, ImageOps, ImageEnhance
import pyautogui
import time
import pygame
import re

TimeToType = 30
Time = 0
TimesTyped = 0
pygame.mixer.init()
TingSound = pygame.mixer.Sound('ting.mp3')
ButtonSound = pygame.mixer.Sound('button.mp3')

def Type(text):
    pyautogui.PAUSE = 0.05
    pyautogui.FAILSAFE = 0

    for char in text:
        if char == "\n":
            pyautogui.press('space')
        else:
            pyautogui.write(char)

def PlaySound(sfx):
    pygame.mixer.music.set_volume(0.2)
    sfx.play()


def FindRange():
    PlaySound(ButtonSound)
    time.sleep(5)
    x, y = pyautogui.position()
    x1 = x
    y1 = y

    PlaySound(ButtonSound)
    time.sleep(5)
    x, y = pyautogui.position()
    x2 = x
    y2 = y

    PlaySound(ButtonSound)
    time.sleep(5)
    x, y = pyautogui.position()
    x3 = x
    y3 = y

    return x1, x2, y1, y2, x3, y3

x1, x2, y1, y2, x3, y3 = FindRange()

#-- Typing starts here --

PlaySound(TingSound)

TimeToStop = time.time() + TimeToType

while time.time() <= TimeToStop:
    if TimesTyped == 0:
        pyautogui.screenshot("Screenshot.png", region=(x1, y1, x2 - x1, y2 - y1))
        text = pytesseract.image_to_string(ImageOps.grayscale(Image.open('Screenshot.png')))
        Type(text)
        TimesTyped = TimesTyped + 1
    else:
        pyautogui.screenshot("Screenshot2.png", region=(x3, y3, x2 - x3, y2 - y3))
        img = Image.open('Screenshot2.png')
        img = ImageOps.grayscale(img)
        enhancer = ImageEnhance.Contrast(img)
        enhanced_img = enhancer.enhance(3.0)
        text = pytesseract.image_to_string(enhanced_img)
        Type(' ' + text)

PlaySound(TingSound)
print("done")
time.sleep(1)
exit()